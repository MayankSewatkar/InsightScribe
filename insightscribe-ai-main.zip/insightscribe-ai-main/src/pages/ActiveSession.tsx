import { useState, useEffect } from "react";
import { Video, VideoOff, Mic, MicOff, Circle, Square } from "lucide-react";
import { mockTranscript, mockBehavioralFlags, type TranscriptEntry, type BehavioralFlag } from "@/lib/mock-data";

const ActiveSession = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [visibleTranscript, setVisibleTranscript] = useState<TranscriptEntry[]>([]);
  const [visibleFlags, setVisibleFlags] = useState<BehavioralFlag[]>([]);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);

  useEffect(() => {
    if (!isRecording) return;
    let idx = 0;
    const interval = setInterval(() => {
      if (idx < mockTranscript.length) {
        const currentEntry = mockTranscript[idx];
        setVisibleTranscript((prev) => [...prev, currentEntry]);
        const matchingFlags = mockBehavioralFlags.filter(
          (f) => f.timestamp === currentEntry.timestamp
        );
        if (matchingFlags.length) {
          setVisibleFlags((prev) => [...prev, ...matchingFlags]);
        }
        idx++;
      } else {
        clearInterval(interval);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [isRecording]);

  const startRecording = () => {
    setVisibleTranscript([]);
    setVisibleFlags([]);
    setIsRecording(true);
  };

  const emotionColors: Record<string, string> = {
    Anxiety: "text-clinical-amber",
    Fear: "text-clinical-red",
    Uncertainty: "text-clinical-amber",
    Insight: "text-clinical-green",
    Openness: "text-clinical-green",
  };

  const flagColors: Record<string, string> = {
    "cognitive-distortion": "border-clinical-red bg-clinical-red-light",
    "emotion-shift": "border-clinical-amber bg-clinical-amber-light",
    insight: "border-clinical-green bg-clinical-green-light",
    avoidance: "border-clinical-amber bg-clinical-amber-light",
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Live Session</h1>
          <p className="text-sm text-muted-foreground">
            {isRecording ? (
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-clinical-red animate-pulse-soft" />
                Recording in progress
              </span>
            ) : (
              "Ready to begin"
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCameraOn(!cameraOn)}
            className="rounded-lg border border-border p-2 text-muted-foreground transition-colors hover:bg-accent"
          >
            {cameraOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
          </button>
          <button
            onClick={() => setMicOn(!micOn)}
            className="rounded-lg border border-border p-2 text-muted-foreground transition-colors hover:bg-accent"
          >
            {micOn ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
          </button>
          {!isRecording ? (
            <button
              onClick={startRecording}
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <Circle className="h-3.5 w-3.5 fill-current" />
              Start Session
            </button>
          ) : (
            <button
              onClick={() => setIsRecording(false)}
              className="inline-flex items-center gap-2 rounded-lg bg-destructive px-4 py-2 text-sm font-medium text-destructive-foreground transition-colors hover:bg-destructive/90"
            >
              <Square className="h-3.5 w-3.5 fill-current" />
              End Session
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4" style={{ height: "calc(100vh - 160px)" }}>
        {/* Column 1: Video + Emotion */}
        <div className="col-span-3 space-y-4">
          <div className="aspect-video overflow-hidden rounded-lg border border-border bg-foreground/5">
            <div className="flex h-full items-center justify-center">
              {cameraOn ? (
                <div className="text-center">
                  <Video className="mx-auto h-8 w-8 text-muted-foreground/40" />
                  <p className="mt-2 text-xs text-muted-foreground">Webcam Feed</p>
                  <p className="text-[10px] text-muted-foreground/60">Connect backend for live video</p>
                </div>
              ) : (
                <VideoOff className="h-8 w-8 text-muted-foreground/30" />
              )}
            </div>
          </div>

          <div className="rounded-lg border border-border bg-card p-3">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
              Emotional Valence
            </h3>
            <div className="space-y-2">
              {["Engagement", "Anxiety", "Sadness", "Guardedness"].map((emotion, i) => {
                const values = [65, 45, 20, 30];
                return (
                  <div key={emotion}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-muted-foreground">{emotion}</span>
                      <span className="font-mono text-foreground">{values[i]}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full bg-primary transition-all duration-1000"
                        style={{ width: `${values[i]}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Column 2: Live Transcript */}
        <div className="col-span-5 flex flex-col rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Live Transcript
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {visibleTranscript.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">
                {isRecording ? "Listening..." : "Start a session to see the transcript"}
              </p>
            )}
            {visibleTranscript.map((entry) => (
              <div key={entry.id} className="group">
                <div className="flex items-start gap-2">
                  <span className="font-mono text-[10px] text-muted-foreground/60 mt-0.5 shrink-0 w-14">
                    {entry.timestamp}
                  </span>
                  <div className="flex-1">
                    <span
                      className={`text-xs font-medium ${
                        entry.speaker === "Therapist" ? "text-primary" : "text-foreground"
                      }`}
                    >
                      {entry.speaker}
                    </span>
                    <p className="text-sm text-foreground/90 leading-relaxed">{entry.text}</p>
                    {entry.emotion && (
                      <span
                        className={`mt-1 inline-block text-[10px] font-medium ${
                          emotionColors[entry.emotion] || "text-muted-foreground"
                        }`}
                      >
                        ● {entry.emotion}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Column 3: Behavioral Indicators */}
        <div className="col-span-4 flex flex-col rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Behavioral Indicators
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {visibleFlags.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">
                {isRecording ? "Analyzing..." : "Flags will appear during the session"}
              </p>
            )}
            {visibleFlags.map((flag) => (
              <div
                key={flag.id}
                className={`rounded-lg border p-3 ${flagColors[flag.type]}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-foreground">{flag.label}</span>
                  <span className="font-mono text-[10px] text-muted-foreground">
                    {flag.timestamp}
                  </span>
                </div>
                <p className="text-xs text-foreground/80 leading-relaxed">{flag.description}</p>
                <span className="mt-1.5 inline-block rounded-full bg-card/60 px-2 py-0.5 text-[10px] font-medium text-muted-foreground capitalize">
                  {flag.type.replace("-", " ")}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActiveSession;
