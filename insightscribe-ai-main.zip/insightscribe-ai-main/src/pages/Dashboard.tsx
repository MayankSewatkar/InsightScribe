import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, Plus, Copy, FileDown, Clock, Tag } from "lucide-react";
import { mockSessions } from "@/lib/mock-data";
import SentimentSparkline from "@/components/SentimentSparkline";

const Dashboard = () => {
  const [search, setSearch] = useState("");

  const filtered = mockSessions.filter(
    (s) =>
      s.clientInitials.toLowerCase().includes(search.toLowerCase()) ||
      s.themes.some((t) => t.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Sessions</h1>
          <p className="text-sm text-muted-foreground">
            {mockSessions.filter((s) => s.status === "completed").length} completed ·{" "}
            {mockSessions.filter((s) => s.status === "scheduled").length} scheduled
          </p>
        </div>
        <Link
          to="/session"
          className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Plus className="h-4 w-4" />
          New Session
        </Link>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search sessions, themes, or client initials..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-lg border border-border bg-card py-2.5 pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div className="space-y-2">
        {filtered.map((session) => (
          <div
            key={session.id}
            className="flex items-center gap-4 rounded-lg border border-border bg-card p-4 transition-colors hover:bg-accent/50 clinical-shadow"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-clinical-blue-light text-sm font-semibold text-primary">
              {session.clientInitials}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">{session.clientInitials}</span>
                <span
                  className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${
                    session.status === "completed"
                      ? "bg-clinical-green-light text-clinical-green"
                      : session.status === "in-progress"
                      ? "bg-clinical-amber-light text-clinical-amber"
                      : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {session.status}
                </span>
                {session.noteType && (
                  <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px] font-mono font-medium text-muted-foreground">
                    {session.noteType}
                  </span>
                )}
              </div>
              {session.summary && (
                <p className="mt-0.5 text-xs text-muted-foreground truncate max-w-lg">
                  {session.summary}
                </p>
              )}
              <div className="mt-1.5 flex items-center gap-3">
                <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {session.date} · {session.duration ? `${session.duration}m` : "Upcoming"}
                </span>
                {session.themes.length > 0 && (
                  <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                    <Tag className="h-3 w-3" />
                    {session.themes.join(", ")}
                  </span>
                )}
              </div>
            </div>

            <SentimentSparkline data={session.sentimentData} />

            {session.status === "completed" && (
              <div className="flex items-center gap-1">
                <button className="rounded p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground" title="Copy to EHR">
                  <Copy className="h-3.5 w-3.5" />
                </button>
                <button className="rounded p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground" title="Export PDF">
                  <FileDown className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
