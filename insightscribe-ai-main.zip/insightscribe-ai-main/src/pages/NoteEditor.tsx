import { useState } from "react";
import { Copy, FileDown, CheckCircle } from "lucide-react";
import { soapTemplate, dapTemplate } from "@/lib/mock-data";

const NoteEditor = () => {
  const [noteType, setNoteType] = useState<"SOAP" | "DAP">("SOAP");
  const [content, setContent] = useState(soapTemplate);
  const [copied, setCopied] = useState(false);

  const switchTemplate = (type: "SOAP" | "DAP") => {
    setNoteType(type);
    setContent(type === "SOAP" ? soapTemplate : dapTemplate);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Simple markdown-to-HTML renderer for preview
  const renderMarkdown = (md: string) => {
    return md
      .split("\n")
      .map((line, i) => {
        if (line.startsWith("## ")) {
          return `<h2 class="text-base font-semibold text-foreground mt-5 mb-2 first:mt-0">${line.slice(3)}</h2>`;
        }
        if (line.startsWith("1. ") || line.match(/^\d+\.\s/)) {
          return `<p class="text-sm text-foreground/85 leading-relaxed pl-4 mb-0.5">${line}</p>`;
        }
        if (line.startsWith("- ")) {
          return `<p class="text-sm text-foreground/85 leading-relaxed pl-4 mb-0.5">• ${line.slice(2)}</p>`;
        }
        if (line.trim() === "") {
          return `<div class="h-2"></div>`;
        }
        return `<p class="text-sm text-foreground/85 leading-relaxed mb-1">${line}</p>`;
      })
      .join("");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Clinical Notes</h1>
          <p className="text-sm text-muted-foreground">J.M. · Feb 23, 2026 · 50 min session</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-border bg-card p-0.5">
            {(["SOAP", "DAP"] as const).map((type) => (
              <button
                key={type}
                onClick={() => switchTemplate(type)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  noteType === type
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {type}
              </button>
            ))}
          </div>
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            {copied ? <CheckCircle className="h-3.5 w-3.5 text-clinical-green" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? "Copied" : "Copy to EHR"}
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
            <FileDown className="h-3.5 w-3.5" />
            Export PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4" style={{ height: "calc(100vh - 160px)" }}>
        {/* Editor */}
        <div className="flex flex-col rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Editor · Markdown
            </h3>
          </div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="flex-1 resize-none bg-transparent p-4 font-mono text-sm text-foreground leading-relaxed focus:outline-none"
            spellCheck={false}
          />
        </div>

        {/* Preview */}
        <div className="flex flex-col rounded-lg border border-border bg-card">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Preview
            </h3>
          </div>
          <div
            className="flex-1 overflow-y-auto p-5"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(content) }}
          />
        </div>
      </div>
    </div>
  );
};

export default NoteEditor;
