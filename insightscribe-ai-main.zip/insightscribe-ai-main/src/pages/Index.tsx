const Index = () => null;
export default Index;
