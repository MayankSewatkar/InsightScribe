import { LineChart, Line, ResponsiveContainer } from "recharts";

interface SentimentSparklineProps {
  data: number[];
}

const SentimentSparkline = ({ data }: SentimentSparklineProps) => {
  if (!data.length) return <span className="text-xs text-muted-foreground">—</span>;

  const chartData = data.map((value, i) => ({ i, v: value }));

  return (
    <div className="h-8 w-24">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <Line
            type="monotone"
            dataKey="v"
            stroke="hsl(221, 83%, 53%)"
            strokeWidth={1.5}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SentimentSparkline;
