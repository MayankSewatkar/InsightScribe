import { Link, useLocation } from "react-router-dom";
import { Activity, FileText, LayoutDashboard, Shield, Video } from "lucide-react";

const navItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/session", label: "Live Session", icon: Video },
  { path: "/notes", label: "Notes", icon: FileText },
];

const AppSidebar = () => {
  const location = useLocation();

  return (
    <aside className="fixed left-0 top-0 z-40 flex h-screen w-60 flex-col border-r border-border bg-card">
      <div className="flex items-center gap-2.5 border-b border-border px-5 py-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
          <Activity className="h-4 w-4 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-sm font-semibold text-foreground">InsightScribe</h1>
          <p className="text-[10px] text-muted-foreground">Clinical Co-Pilot</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-4">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors ${
                isActive
                  ? "bg-clinical-blue-light text-primary font-medium"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground"
              }`}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-border px-4 py-3">
        <div className="flex items-center gap-2 rounded-md bg-clinical-green-light px-3 py-2">
          <Shield className="h-3.5 w-3.5 text-clinical-green" />
          <span className="text-xs font-medium text-clinical-green">100% Local · HIPAA Safe</span>
        </div>
      </div>
    </aside>
  );
};

export default AppSidebar;
