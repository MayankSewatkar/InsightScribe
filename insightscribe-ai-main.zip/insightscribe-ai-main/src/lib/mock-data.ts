export interface Session {
  id: string;
  clientInitials: string;
  date: string;
  duration: number; // minutes
  status: "completed" | "in-progress" | "scheduled";
  themes: string[];
  sentimentData: number[]; // -1 to 1 range
  noteType?: "SOAP" | "DAP";
  summary?: string;
}

export interface TranscriptEntry {
  id: string;
  timestamp: string;
  speaker: "Therapist" | "Client";
  text: string;
  emotion?: string;
  intensity?: number;
}

export interface BehavioralFlag {
  id: string;
  timestamp: string;
  type: "cognitive-distortion" | "emotion-shift" | "avoidance" | "insight";
  label: string;
  description: string;
  severity: "low" | "medium" | "high";
}

export const mockSessions: Session[] = [
  {
    id: "s1",
    clientInitials: "J.M.",
    date: "2026-02-23",
    duration: 50,
    status: "completed",
    themes: ["Anxiety", "Work Stress", "Sleep"],
    sentimentData: [0.2, 0.1, -0.3, -0.5, -0.2, 0.1, 0.3, 0.4, 0.5, 0.3],
    noteType: "SOAP",
    summary: "Client reports increased workplace anxiety following a role change. Sleep disturbances noted.",
  },
  {
    id: "s2",
    clientInitials: "A.R.",
    date: "2026-02-22",
    duration: 45,
    status: "completed",
    themes: ["Depression", "Relationships", "Self-worth"],
    sentimentData: [-0.4, -0.6, -0.5, -0.3, -0.1, 0.0, 0.2, 0.1, 0.3, 0.2],
    noteType: "DAP",
    summary: "Explored core beliefs around self-worth tied to recent relationship conflict.",
  },
  {
    id: "s3",
    clientInitials: "K.L.",
    date: "2026-02-21",
    duration: 50,
    status: "completed",
    themes: ["PTSD", "Hypervigilance", "Grounding"],
    sentimentData: [-0.2, -0.4, -0.7, -0.5, -0.3, -0.1, 0.1, 0.2, 0.3, 0.4],
    noteType: "SOAP",
    summary: "Continued trauma processing. Client practiced grounding techniques with positive response.",
  },
  {
    id: "s4",
    clientInitials: "T.W.",
    date: "2026-02-23",
    duration: 0,
    status: "scheduled",
    themes: [],
    sentimentData: [],
  },
  {
    id: "s5",
    clientInitials: "M.B.",
    date: "2026-02-20",
    duration: 50,
    status: "completed",
    themes: ["Grief", "Acceptance", "Coping"],
    sentimentData: [-0.6, -0.7, -0.5, -0.4, -0.3, -0.2, 0.0, 0.1, 0.0, -0.1],
    noteType: "SOAP",
  },
];

export const mockTranscript: TranscriptEntry[] = [
  { id: "t1", timestamp: "00:00:32", speaker: "Therapist", text: "How have things been since our last session?" },
  { id: "t2", timestamp: "00:00:48", speaker: "Client", text: "Honestly, not great. The anxiety at work has gotten worse since the restructuring.", emotion: "Anxiety", intensity: 0.7 },
  { id: "t3", timestamp: "00:01:15", speaker: "Therapist", text: "Tell me more about what's been happening at work." },
  { id: "t4", timestamp: "00:01:35", speaker: "Client", text: "I feel like everything I do is wrong. My new manager barely talks to me, and I just know they're going to let me go.", emotion: "Fear", intensity: 0.8 },
  { id: "t5", timestamp: "00:02:10", speaker: "Therapist", text: "I notice you said you 'just know' — what evidence do you have for that thought?" },
  { id: "t6", timestamp: "00:02:35", speaker: "Client", text: "Well... I guess I don't have direct evidence. But the silence feels threatening.", emotion: "Uncertainty", intensity: 0.5 },
  { id: "t7", timestamp: "00:03:05", speaker: "Therapist", text: "That's an important distinction. The feeling is real, but the interpretation might not match reality." },
  { id: "t8", timestamp: "00:03:30", speaker: "Client", text: "I hadn't thought about it that way. Maybe I'm catastrophizing again.", emotion: "Insight", intensity: 0.4 },
  { id: "t9", timestamp: "00:04:00", speaker: "Therapist", text: "Great awareness. Let's work with that. What would a more balanced thought look like?" },
  { id: "t10", timestamp: "00:04:25", speaker: "Client", text: "Maybe... that the silence is just because they're also adjusting to a new role?", emotion: "Openness", intensity: 0.3 },
];

export const mockBehavioralFlags: BehavioralFlag[] = [
  { id: "b1", timestamp: "00:01:35", type: "cognitive-distortion", label: "Fortune Telling", description: "Client predicts negative outcome without evidence ('they're going to let me go').", severity: "high" },
  { id: "b2", timestamp: "00:01:35", type: "cognitive-distortion", label: "All-or-Nothing", description: "Client uses absolute language: 'everything I do is wrong'.", severity: "medium" },
  { id: "b3", timestamp: "00:02:35", type: "emotion-shift", label: "Anxiety → Uncertainty", description: "Emotional intensity decreased when prompted to examine evidence.", severity: "low" },
  { id: "b4", timestamp: "00:03:30", type: "insight", label: "Self-Recognition", description: "Client independently identifies catastrophizing pattern.", severity: "low" },
  { id: "b5", timestamp: "00:04:25", type: "insight", label: "Cognitive Reframe", description: "Client generates alternative interpretation voluntarily.", severity: "low" },
];

export const soapTemplate = `## Subjective
Client reports increased workplace anxiety following recent organizational restructuring. States feeling that "everything I do is wrong" and fears job loss. Reports sleep disturbances — difficulty falling asleep due to rumination.

## Objective
- Affect: Anxious, mildly agitated at session start; calmer by mid-session
- Behavioral observations: Fidgeting, rapid speech initially; slowed as session progressed
- Cognitive patterns: Fortune telling, all-or-nothing thinking identified
- Emotional valence: Started negative (-0.5), trended positive (+0.4) by end

## Assessment
Client demonstrates characteristic anxiety-driven cognitive distortions, particularly catastrophizing and mind-reading. Positive indicators include self-awareness of patterns and ability to generate alternative interpretations with minimal prompting. GAD-7 screening recommended for next session.

## Plan
1. Continue CBT-based cognitive restructuring
2. Assign thought record homework focusing on work-related automatic thoughts
3. Introduce progressive muscle relaxation for sleep hygiene
4. Administer GAD-7 at next session
5. Next session: February 28, 2026`;

export const dapTemplate = `## Data
Client attended a 50-minute individual therapy session. Presented with elevated anxiety related to workplace restructuring. Reported difficulty sleeping, racing thoughts, and fear of job loss. Key statements: "Everything I do is wrong" and "I just know they're going to let me go." Session included examination of evidence for catastrophic predictions.

## Assessment
Client's anxiety appears primarily driven by cognitive distortions (fortune telling, all-or-nothing thinking) rather than objective workplace threat. Notably, client demonstrated capacity for self-reflection, independently identifying catastrophizing pattern and generating balanced alternative thought. Emotional trajectory during session moved from high anxiety to tentative openness. Therapeutic alliance remains strong.

## Plan
1. Continue cognitive-behavioral interventions targeting automatic thoughts
2. Thought record assignment: 3x/week minimum, focusing on workplace triggers
3. Introduce relaxation technique for sleep onset difficulty
4. Consider GAD-7 assessment at next visit
5. Follow-up scheduled: February 28, 2026`;
